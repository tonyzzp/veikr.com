package org.zzp.mail.mine;

public class Test {
	public static void main(String[] args) {
		MyMailSender mail=new MyMailSender();
		mail.setSenderAccount("发件人用户名");
		mail.setSenderPassword("发件人密码");
		mail.setSenderName("发件人显示姓名");
		mail.setSenderAddress("发件邮箱地址");
		mail.setHost("发件人smtp服务器地址");
		mail.setSubject("邮件主题");
		mail.setBody("邮件正文");
		mail.addTo("收件人地址");
		mail.addTo("收件人地址");
		mail.addCC("抄送地址");
		mail.addBCC("密送地址");
		try {
			System.out.println("正在发送");
			mail.send();
			System.out.println("成功");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}