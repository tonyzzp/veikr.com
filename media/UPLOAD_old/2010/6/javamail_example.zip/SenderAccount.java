package org.zzp.mail.mine;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;

public class SenderAccount extends Authenticator {
	private String username;
	private String password;
	private String senderAddress;
	private String senderName;
	private String host;
	
	public SenderAccount(){
		super();
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getSenderAddress() {
		return senderAddress;
	}
	public void setSenderAddress(String fromAddress) {
		senderAddress = fromAddress;
	}
	public String getSenderName() {
		return senderName;
	}
	public void setSenderName(String fromName) {
		senderName = fromName;
	}
	public String getHost() {
		return host;
	}
	public void setHost(String host) {
		this.host = host;
	}
	public PasswordAuthentication getPasswordAuthentication(){
		return new PasswordAuthentication(username,password);
	}
}