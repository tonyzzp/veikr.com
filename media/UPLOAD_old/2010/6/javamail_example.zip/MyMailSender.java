package org.zzp.mail.mine;

import java.util.HashSet;
import java.util.Properties;
import java.util.Set;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class MyMailSender {
	private Set<String> to;
	private Set<String> cc;
	private Set<String> bcc;
	private String subject;
	private String body;
	private SenderAccount senderAccount;

	public MyMailSender() {
		to = new HashSet<String>();
		cc = new HashSet<String>();
		bcc = new HashSet<String>();
		senderAccount = new SenderAccount();
	}

	public void setSenderAccount(String username) {
		this.senderAccount.setUsername(username);
	}

	public void setSenderPassword(String senderPassword) {
		this.senderAccount.setPassword(senderPassword);
	}

	public void setSenderAddress(String senderAddress) {
		this.senderAccount.setSenderAddress(senderAddress);
	}

	public void setSenderName(String senderName) {
		this.senderAccount.setSenderName(senderName);
	}

	public void setHost(String host) {
		this.senderAccount.setHost(host);
	}

	public String getHost() {
		return this.senderAccount.getHost();
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String title) {
		this.subject = title;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public void addTo(String to) {
		this.to.add(to);
	}

	public void addCC(String e) {
		this.cc.add(e);
	}

	public void addBCC(String e) {
		this.bcc.add(e);
	}

	// 发送
	public void send() throws Exception {
		Properties props = new Properties();
		props.put("mail.smtp.host", senderAccount.getHost());
		props.put("mail.smtp.auth", "true");
		Session session = Session.getDefaultInstance(props, senderAccount);
		MimeMessage message = new MimeMessage(session);
		message.setSubject(subject);
		message.setText(body);
		message.setFrom(new InternetAddress(senderAccount.getSenderAddress(),
				senderAccount.getSenderName()));
		// 添加收件人
		for (String s : to) {
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(
					s));
		}
		// 添加抄送
		for (String s : cc) {
			message.addRecipient(Message.RecipientType.CC, 
					new InternetAddress(s));
		}
		// 添加密送
		for (String s : bcc) {
			message.addRecipient(Message.RecipientType.BCC,
					new InternetAddress(s));
		}
		// message.setSentDate(new Date(1988,10,12));
		Transport.send(message);
	}
}