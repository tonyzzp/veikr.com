package zzp.test.calllistener;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class CalllistenerActivity extends Activity {
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		TextView tv = new TextView(this);
		String pwd = getIntent().getStringExtra("data");
		tv.setText(pwd);
		setContentView(tv);
	}
}