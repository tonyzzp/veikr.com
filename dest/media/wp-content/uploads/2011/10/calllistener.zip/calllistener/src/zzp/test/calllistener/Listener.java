package zzp.test.calllistener;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class Listener extends BroadcastReceiver {

	@Override
	public void onReceive(Context context, Intent intent) {
		Tool.showIntent(intent);
		String pwd = intent.getData().getHost();
		Intent i = new Intent(context, CalllistenerActivity.class);
		i.putExtra("data", pwd);
		i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		context.startActivity(i);
	}
}