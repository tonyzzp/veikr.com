package zzp.test.calllistener;

import java.util.Set;

import android.content.Intent;
import android.os.Bundle;

public class Tool {
	public static void showIntent(Intent intent) {
		System.out.println(intent);
		Bundle data=intent.getExtras();
		if(data!=null){
			System.out.println(data);
			Set<String> keys= data.keySet();
			for(String key:keys){
				System.out.println(key+"="+data.getString(key));
			}
		}
	}
}