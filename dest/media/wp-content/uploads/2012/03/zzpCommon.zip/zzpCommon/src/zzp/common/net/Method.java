package zzp.common.net;

public enum Method {
	GET, POST
}