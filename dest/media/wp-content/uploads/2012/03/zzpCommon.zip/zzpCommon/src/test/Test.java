package test;

import java.io.File;

import zzp.common.net.HttpRequest;
import zzp.common.net.HttpResponse;
import zzp.common.net.HttpUtils;
import zzp.common.net.Method;

public class Test {
	public static void main(String[] args) throws Exception {
		// HttpRequest request = new
		// HttpRequest("http://veikr.com/test/post.php");
		// request.addParam("name", "章治鹏");
		// request.addParam("age", "23");
		// request.setMethod(Method.POST);
		// HttpResponse response = request.exeute();
		// System.out.println(response);
		// System.out.println(HttpUtils.getString(response));

		HttpRequest request = new HttpRequest(
				"http://veikr.com/test/upload.php");
		request.setMethod(Method.POST);
		request.addParam("name", "章治鹏");
		request.addParam("age", "23");
		request.addFile("pic1", new File("g:/a/哪个朝代最腐败.png"));
		request.addFile("pic2", new File("g:/a/a.txt"));
		HttpResponse response = request.exeute();
		System.out.println(response);
		System.out.println(HttpUtils.getString(response));
	}
}