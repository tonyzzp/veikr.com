package zzp.musicwidget;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.farng.mp3.MP3File;
import org.farng.mp3.TagException;
import org.farng.mp3.id3.AbstractID3v2;
import org.farng.mp3.id3.ID3v1;
import zzp.musicwidget.R;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.MediaPlayer;
import android.os.IBinder;

public class MusicService extends Service {
	private MediaPlayer player;
	private List<String> data;
	private int location = 0;
	private BroadcastReceiver receiver;

	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		System.out.println("music service  create");
	}

	@Override
	public void onStart(Intent intent, int startId) {
		super.onStart(intent, startId);
		System.out.println("music service onbind");
		player = new MediaPlayer();
		data = new ArrayList<String>();
		System.out.println("开始加载音乐");
		File file = new File("/mnt/sdcard/veikrmusic");
		File[] files = file.listFiles();
		for (File f : files) {
			if (f.isFile() && f.getName().endsWith(".mp3")) {
				data.add(f.getAbsolutePath());
			}
		}
		System.out.println("音乐加载ok:" + data.size());

		try {
			player.setDataSource(data.get(location));
			player.prepare();
		} catch (IllegalArgumentException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IllegalStateException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		receiver = new BroadcastReceiver() {
			@Override
			public void onReceive(Context context, Intent intent) {
				System.out.println("service receive:" + intent);
				String action = intent.getAction();
				if (action.equals("zzp.musicwidget.playorpause")) {
					if (!player.isPlaying()) {
						try {
							player.start();
							sendPlay();
						} catch (IllegalStateException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					} else {
						player.pause();
						sendPause();
					}
				} else if (action.equals("zzp.musicwidget.next")) {
					playNext();
				} else if (action.equals("zzp.musicwidget.previous")) {
					playPrevious();
				}
			}
		};

		IntentFilter filter = new IntentFilter();
		filter.addAction("zzp.musicwidget.next");
		filter.addAction("zzp.musicwidget.playorpause");
		filter.addAction("zzp.musicwidget.previous");
		registerReceiver(receiver, filter);
	}

	public void playNext() {
		if (location < data.size() - 1) {
			location++;
		} else if (location == data.size() - 1) {
			location = 0;
		}
		play();
	}

	public void playPrevious() {
		if (location == 0) {
			location = data.size() - 1;
		} else if (location > 0) {
			location--;
		}
		play();
	}

	public void play() {
		System.out.println("播放第" + location + "首");
		try {
			// player.release();
			// player = null;
			// player = new MediaPlayer();
			player.reset();
			player.setDataSource(data.get(location));
			player.prepare();
			player.start();
			sendPlay();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void onDestroy() {
		unregisterReceiver(receiver);
		super.onDestroy();
	}

	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}

	/**
	 * 发送播放通知，以便widget改变图标样式
	 */
	public void sendPlay() {
		Intent play = new Intent("zzp.musicwidget.widget.play");
		sendBroadcast(play);
		try {
			sendTitle();
		} catch (Exception e) {

		}
	}

	public void sendPause() {
		Intent play = new Intent("zzp.musicwidget.widget.pause");
		sendBroadcast(play);
	}

	/**
	 * 发送歌曲标题到widget
	 */
	public void sendTitle() {
		String filepath = data.get(location);
		System.out.println(filepath);
		MP3File mp3 = null;
		try {
			mp3 = new MP3File(filepath);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TagException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		AbstractID3v2 id3v2 = mp3.getID3v2Tag();
		ID3v1 id3v1 = null;
		if (id3v2 == null) {
			id3v1 = mp3.getID3v1Tag();
		}
		String title = "";
		if (id3v2 != null) {
			title = id3v2.getLeadArtist() + " - " + id3v2.getSongTitle();
		} else if (id3v1 != null) {
			title = id3v1.getLeadArtist() + " - " + id3v1.getSongTitle();
		}
		Intent i = new Intent("zzp.musicwidget.widget.title");
		i.putExtra(Intent.EXTRA_TEXT, title);
		sendBroadcast(i);
	}
}