package zzp.musicwidget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import zzp.musicwidget.R;

public class MusicWidgetProvider extends AppWidgetProvider {

	@Override
	public void onReceive(Context context, Intent intent) {
		super.onReceive(context, intent);
		System.out.println("provider receive:" + intent);
		String action = intent.getAction();
		RemoteViews views = new RemoteViews(context.getPackageName(),
				R.layout.widget);
		if (action.equals("zzp.musicwidget.widget.play")) {
			views.setImageViewResource(R.id.play, R.drawable.pause);
		} else if (action.equals("zzp.musicwidget.widget.pause")) {
			views.setImageViewResource(R.id.play, R.drawable.play);
		} else if (action.equals("zzp.musicwidget.widget.title")) {
			views.setTextViewText(R.id.textView1,
					intent.getStringExtra(Intent.EXTRA_TEXT));
		}

		// 改变完成后，请一定要记住调用updateAppWidget方法，否则改变不会生效
		AppWidgetManager mgr = AppWidgetManager.getInstance(context);
		mgr.updateAppWidget(new ComponentName(context,
				MusicWidgetProvider.class), views);
	}

	@Override
	public void onUpdate(Context context, AppWidgetManager appWidgetManager,
			int[] appWidgetIds) {
		super.onUpdate(context, appWidgetManager, appWidgetIds);

		// 在这里给widget里的控件添加监听事件
		RemoteViews views = new RemoteViews(context.getPackageName(),
				R.layout.widget);
		Intent inext = new Intent("zzp.musicwidget.next");
		PendingIntent pnext = PendingIntent.getBroadcast(context, 0, inext, 0);
		Intent iprevious = new Intent("zzp.musicwidget.previous");
		PendingIntent pprevious = PendingIntent.getBroadcast(context, 0,
				iprevious, 0);
		Intent iplay = new Intent("zzp.musicwidget.playorpause");
		PendingIntent pplay = PendingIntent.getBroadcast(context, 0, iplay, 0);
		views.setOnClickPendingIntent(R.id.next, pnext);
		views.setOnClickPendingIntent(R.id.play, pplay);
		views.setOnClickPendingIntent(R.id.previous, pprevious);
		// 不要忘记updateAppWidget
		AppWidgetManager mgr = AppWidgetManager.getInstance(context);
		mgr.updateAppWidget(new ComponentName(context,
				MusicWidgetProvider.class), views);
	}

	@Override
	public void onEnabled(Context context) {
		super.onEnabled(context);
		Intent intent = new Intent(context, MusicService.class);
		context.startService(intent);
	}

	@Override
	public void onDisabled(Context context) {
		// 当widget删除时，停止musicService
		super.onDisabled(context);
		Intent intent = new Intent(context, MusicService.class);
		context.stopService(intent);
	}
}