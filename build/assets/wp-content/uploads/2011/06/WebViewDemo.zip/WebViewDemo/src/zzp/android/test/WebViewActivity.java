package zzp.android.test;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.Toast;

public class WebViewActivity extends Activity {
	Button bt;
	WebView webView;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		webView = new WebView(this);
		setContentView(webView);
		webView.loadUrl("http://veikr.com/wap/");
		webView.getSettings().setJavaScriptEnabled(true);
		webView.addJavascriptInterface(new Handler(), "handler");
		webView.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageFinished(WebView view, String url) {
				Toast.makeText(WebViewActivity.this, "��ҳ�������", 0).show();
				view.loadUrl("javascript:window.handler.show(document.body.innerHTML);");
				super.onPageFinished(view, url);
			}
		});
	}

	class Handler {
		public void show(String data) {
			Toast.makeText(WebViewActivity.this, "ִ����handler.show����", 0).show();
			new AlertDialog.Builder(WebViewActivity.this).setMessage(data).create().show();
		}
	}
}